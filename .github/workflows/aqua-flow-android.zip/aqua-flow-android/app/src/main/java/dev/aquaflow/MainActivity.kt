package dev.aquaflow

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(28, 36, 28, 28); setBackgroundColor(Color.rgb(8,18,30)) }
    val title = TextView(this).apply { text = "AQUA FLOW"; textSize = 30f; setTextColor(Color.rgb(100,220,255)); gravity = Gravity.CENTER; setPadding(0,20,0,12) }
    val sub = TextView(this).apply { text = "GPU water-ripple overlay • touch-reactive • root input bridge"; textSize = 14f; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER; setPadding(0,0,0,24) }
    val start = Button(this).apply { text = "ENABLE WATER OVERLAY" }
    val stop = Button(this).apply { text = "STOP OVERLAY" }
    val info = TextView(this).apply { text = "Grant Display over other apps. For screen-wide touch feedback, grant root when prompted. Root input formats differ by device, so check diagnostics if ripples do not follow global touches."; setTextColor(Color.WHITE); textSize = 14f; setPadding(4,22,4,10) }
    root.addView(title, LinearLayout.LayoutParams(-1, -2)); root.addView(sub, LinearLayout.LayoutParams(-1,-2)); root.addView(start, LinearLayout.LayoutParams(-1,-2)); root.addView(stop, LinearLayout.LayoutParams(-1,-2)); root.addView(info, LinearLayout.LayoutParams(-1,-2)); setContentView(root)
    start.setOnClickListener {
      if (!Settings.canDrawOverlays(this)) { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))); return@setOnClickListener }
      try { startService(Intent(this, WaterService::class.java)); Toast.makeText(this,"Aqua Flow started",Toast.LENGTH_SHORT).show() } catch (e: Exception) { Toast.makeText(this,e.message ?: "Could not start",Toast.LENGTH_LONG).show() }
    }
    stop.setOnClickListener { stopService(Intent(this, WaterService::class.java)); Toast.makeText(this,"Aqua Flow stopped",Toast.LENGTH_SHORT).show() }
  }
}
