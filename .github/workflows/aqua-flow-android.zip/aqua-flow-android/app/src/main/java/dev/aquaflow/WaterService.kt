package dev.aquaflow

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.Toast
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread

class WaterService : Service() {
  private lateinit var wm: WindowManager
  private var water: WaterView? = null
  private var rootBridge: RootTouchBridge? = null
  override fun onBind(intent: Intent?): IBinder? = null

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
    if (water != null) return START_STICKY
    wm = getSystemService(WINDOW_SERVICE) as WindowManager
    water = WaterView(this)
    val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
    val params = WindowManager.LayoutParams(-1, -1, type,
      WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
      PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; title = "Aqua Flow Water Shader" }
    try { wm.addView(water, params) } catch (e: Exception) { Toast.makeText(this,"Overlay error: ${e.message}",Toast.LENGTH_LONG).show(); stopSelf(); return START_NOT_STICKY }
    rootBridge = RootTouchBridge { x, y, down -> water?.pushTouch(x, y, down) }.also { it.start() }
    return START_STICKY
  }

  override fun onDestroy() {
    rootBridge?.stop(); rootBridge = null
    water?.let { try { wm.removeView(it) } catch (_: Exception) {} }; water = null
    super.onDestroy()
  }
}

/** Reads Linux input events without consuming them. Android continues receiving the same events. */
private class RootTouchBridge(private val onTouch: (Float, Float, Boolean) -> Unit) {
  private val running = AtomicBoolean(false)
  private var proc: Process? = null
  private var worker: Thread? = null
  fun start() {
    if (!running.compareAndSet(false, true)) return
    worker = thread(name = "AquaRootInput", isDaemon = true) {
      try {
        // getevent's labeled output varies across Android kernels; this parser accepts common forms.
        proc = Runtime.getRuntime().exec(arrayOf("su", "-c", "getevent -lt"))
        val reader = BufferedReader(InputStreamReader(proc!!.inputStream))
        var rawX = -1f; var rawY = -1f; var down = false
        while (running.get()) {
          val line = reader.readLine() ?: break
          val upper = line.uppercase()
          val value = Regex("(?:ABS_MT_POSITION_X|ABS_X)\\s+([0-9A-FX]+)").find(upper)?.groupValues?.get(1)
          val valueY = Regex("(?:ABS_MT_POSITION_Y|ABS_Y)\\s+([0-9A-FX]+)").find(upper)?.groupValues?.get(1)
          fun parse(s: String?): Float? = s?.let { runCatching { (if (it.startsWith("0X")) it.substring(2).toLong(16) else it.toLong(16)).toFloat() }.getOrNull() }
          parse(value)?.let { rawX = it }; parse(valueY)?.let { rawY = it }
          if (upper.contains("BTN_TOUCH") || upper.contains("BTN_TOOL_FINGER")) {
            val token = upper.substringAfterLast(' ').trim()
            if (token == "DOWN" || token == "1") down = true
            if (token == "UP" || token == "0") down = false
          }
          if (rawX >= 0 && rawY >= 0 && (upper.contains("ABS_MT_POSITION") || upper.contains("ABS_X") || upper.contains("ABS_Y"))) {
            // Convert common 0..4095/0..32767 raw ranges to normalized coordinates.
            // See README for device-specific calibration when the touch controller differs.
            val nx = (rawX / 4095f).coerceIn(0f, 1f)
            val ny = (rawY / 4095f).coerceIn(0f, 1f)
            onTouch(nx, ny, true)
          }
          if (upper.contains("BTN_TOUCH") && (upper.contains("UP") || upper.endsWith(" 0"))) onTouch(-1f, -1f, false)
        }
      } catch (_: Exception) { /* Root denied or getevent output unsupported: app remains usable. */ }
      finally { running.set(false) }
    }
  }
  fun stop() { running.set(false); try { proc?.destroy() } catch (_: Exception) {}; worker?.interrupt(); worker = null; proc = null }
}
