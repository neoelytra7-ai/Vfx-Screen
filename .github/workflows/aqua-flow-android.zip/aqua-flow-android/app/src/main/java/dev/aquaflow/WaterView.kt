package dev.aquaflow

import android.content.Context
import android.opengl.GLSurfaceView
import android.opengl.GLES20
import android.view.MotionEvent
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.util.concurrent.CopyOnWriteArrayList
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.max

class WaterView(context: Context) : GLSurfaceView(context) {
  private val rendererImpl = WaterRenderer()
  init { setEGLContextClientVersion(2); setEGLConfigChooser(8,8,8,8,0,0); setRenderer(rendererImpl); renderMode = RENDERMODE_CONTINUOUSLY; setZOrderOnTop(true); holder.setFormat(android.graphics.PixelFormat.TRANSLUCENT) }
  fun pushTouch(x: Float, y: Float, down: Boolean) { rendererImpl.touch(x, y, down) }
  override fun onTouchEvent(event: MotionEvent): Boolean {
    val w = max(1, width).toFloat(); val h = max(1, height).toFloat()
    when (event.actionMasked) {
      MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE, MotionEvent.ACTION_POINTER_DOWN -> for (i in 0 until event.pointerCount) rendererImpl.touch(event.getX(i)/w, event.getY(i)/h, true)
      MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> rendererImpl.touch(-1f,-1f,false)
    }
    return true
  }
}

private data class Ripple(val x: Float, val y: Float, val born: Long, val power: Float)
private class WaterRenderer : GLSurfaceView.Renderer {
  private val ripples = CopyOnWriteArrayList<Ripple>()
  private val epoch = System.nanoTime()
  @Volatile private var latestX = -1f; @Volatile private var latestY = -1f; @Volatile private var latestDown = false
  private var program = 0; private var pos = 0; private var timeLoc = 0; private var resLoc = 0; private var touchLoc = 0; private var downLoc = 0; private var rippleLoc = 0; private var powerLoc = 0
  private var width = 1; private var height = 1
  private val coords: FloatBuffer = ByteBuffer.allocateDirect(8*4).order(ByteOrder.nativeOrder()).asFloatBuffer().put(floatArrayOf(-1f,-1f,1f,-1f,-1f,1f,1f,1f)).apply { position(0) }
  fun touch(x: Float, y: Float, down: Boolean) {
    latestX=x; latestY=y; latestDown=down
    if (down && x >= 0 && y >= 0) { ripples.add(Ripple(x, y, System.nanoTime() - epoch, 1f)); while (ripples.size > 10) ripples.removeAt(0) }
  }
  override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
    GLES20.glClearColor(0f,0f,0f,0f)
    val vs = "attribute vec2 aPos; varying vec2 uv; void main(){ uv=(aPos+1.0)*0.5; gl_Position=vec4(aPos,0.0,1.0); }"
    val fs = """
      precision highp float;
      varying vec2 uv;
      uniform vec2 uRes; uniform float uTime; uniform vec2 uTouch; uniform float uDown;
      uniform vec4 uRipples[10]; uniform float uPower;
      void main(){
        vec2 p=uv; p.x*=uRes.x/uRes.y;
        float wave=0.0; float glow=0.0;
        for(int i=0;i<10;i++){
          vec4 r=uRipples[i]; if(r.z>0.0){
            vec2 c=r.xy; c.x*=uRes.x/uRes.y; float d=distance(p,c);
            float age=uTime-r.z; float radius=age*0.36;
            float envelope=exp(-age*1.35)*smoothstep(1.2,0.0,abs(d-radius));
            wave += sin((d-radius)*105.0)*envelope*r.w;
            glow += exp(-abs(d-radius)*65.0)*exp(-age*1.4)*r.w;
          }
        }
        vec2 tc=uTouch; tc.x*=uRes.x/uRes.y;
        float td=distance(p,tc);
        float halo=exp(-td*15.0)*uDown;
        float caustic=pow(max(0.0,sin(p.x*38.0+p.y*23.0+uTime*2.0+wave*2.0)),9.0)*glow*0.35;
        float alpha=clamp(abs(wave)*0.42+glow*0.28+caustic+halo*0.16,0.0,0.68);
        vec3 col=vec3(0.20,0.78,1.0)*(0.25+glow*0.8)+vec3(0.72,0.96,1.0)*(abs(wave)*0.55+caustic);
        gl_FragColor=vec4(col,alpha);
      }
    """.trimIndent()
    program = link(compile(GLES20.GL_VERTEX_SHADER,vs), compile(GLES20.GL_FRAGMENT_SHADER,fs))
    pos=GLES20.glGetAttribLocation(program,"aPos"); timeLoc=GLES20.glGetUniformLocation(program,"uTime"); resLoc=GLES20.glGetUniformLocation(program,"uRes"); touchLoc=GLES20.glGetUniformLocation(program,"uTouch"); downLoc=GLES20.glGetUniformLocation(program,"uDown"); rippleLoc=GLES20.glGetUniformLocation(program,"uRipples"); powerLoc=GLES20.glGetUniformLocation(program,"uPower")
    GLES20.glEnable(GLES20.GL_BLEND); GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA,GLES20.GL_ONE_MINUS_SRC_ALPHA)
  }
  override fun onSurfaceChanged(gl: GL10?, w: Int, h: Int) { width=w; height=h; GLES20.glViewport(0,0,w,h) }
  override fun onDrawFrame(gl: GL10?) {
    GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT); GLES20.glUseProgram(program)
    val now=System.nanoTime(); val t=(now-epoch)/1_000_000_000f
    GLES20.glUniform1f(timeLoc,t); GLES20.glUniform2f(resLoc,width.toFloat(),height.toFloat()); GLES20.glUniform2f(touchLoc,latestX,1f-latestY); GLES20.glUniform1f(downLoc,if(latestDown)1f else 0f); GLES20.glUniform1f(powerLoc,1f)
    val data=FloatArray(40); ripples.removeAll { (now-epoch-it.born)/1e9 > 2.6 }
    ripples.take(10).forEachIndexed { i,r -> data[i*4]=r.x; data[i*4+1]=1f-r.y; data[i*4+2]=(r.born/1_000_000_000f); data[i*4+3]=r.power }
    GLES20.glUniform4fv(rippleLoc,10,data,0)
    coords.position(0); GLES20.glEnableVertexAttribArray(pos); GLES20.glVertexAttribPointer(pos,2,GLES20.GL_FLOAT,false,0,coords); GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP,0,4); GLES20.glDisableVertexAttribArray(pos)
  }
  private fun compile(type:Int, src:String):Int { val s=GLES20.glCreateShader(type); GLES20.glShaderSource(s,src); GLES20.glCompileShader(s); val ok=IntArray(1); GLES20.glGetShaderiv(s,GLES20.GL_COMPILE_STATUS,ok,0); if(ok[0]==0) throw RuntimeException("Shader compile failed: "+GLES20.glGetShaderInfoLog(s)); return s }
  private fun link(v:Int,f:Int):Int { val p=GLES20.glCreateProgram(); GLES20.glAttachShader(p,v); GLES20.glAttachShader(p,f); GLES20.glLinkProgram(p); val ok=IntArray(1); GLES20.glGetProgramiv(p,GLES20.GL_LINK_STATUS,ok,0); if(ok[0]==0) throw RuntimeException("Shader link failed: "+GLES20.glGetProgramInfoLog(p)); return p }
}
