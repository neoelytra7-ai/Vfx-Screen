# Aqua Flow — Android water shader overlay

A fresh native Kotlin + OpenGL ES 2.0 prototype. It draws translucent animated water ripples in a full-screen overlay and includes a best-effort root `getevent` reader for global touch coordinates. No existing CineOverlay code is required.

## Build

Open this folder in Android Studio (JDK 17; Android Gradle Plugin 8.7.3) and build the `app` debug APK. Or run `gradle assembleDebug` with a compatible Gradle installation. The APK output is `app/build/outputs/apk/debug/app-debug.apk`.

## Install/use

1. Install the debug APK.
2. Open Aqua Flow and grant **Display over other apps**.
3. Tap **ENABLE WATER OVERLAY**.
4. Grant the root prompt if your superuser manager asks.
5. Tap **STOP OVERLAY** to remove it.

## Important limitations

- Android/OEM kernels differ in `getevent` output and touch-controller ranges. The bridge currently assumes common raw ranges around 0..4095 and is best-effort; on some devices global touch alignment will need calibration or a device-specific event parser. Root alone does not guarantee identical input formats.
- The overlay is intentionally `FLAG_NOT_TOUCHABLE` so it does not steal touches from apps. Local touch input is supported by the view, but because the view is non-touchable in overlay mode, normal operation relies on the root input bridge.
- This is a source prototype, not a tested binary. Build and test on the target phone; if global touches do not line up, inspect `su -c 'getevent -lp'` and adapt the coordinate range/device selection in `RootTouchBridge`.
- It renders translucent refractive-looking ripple highlights, not true background-pixel refraction. True screen refraction requires a permitted screen-capture source (MediaProjection consent) or OEM/system compositor integration; ordinary overlays cannot sample pixels from apps beneath them.
- Do not run the root input reader on a device you do not own or administer.
